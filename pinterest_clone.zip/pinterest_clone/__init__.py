def views():
    return None